@echo off
title NAKSHA 3D Desktop Workstation - Ministry of Rural Development
echo ===================================================================
echo     NAKSHA 3D Desktop Application Suite v2.4.0 (Windows 64-bit)
echo     Department of Land Resources (DoLR), MoRD
echo     Technology Partner: MPSEDC
echo ===================================================================
echo.
echo [1/2] Initializing Standalone Desktop Workstation Window...
echo [2/2] Opening NAKSHA Workstation Window...
echo.
if exist "node_modules\electron\dist\electron.exe" (
    start "" "node_modules\electron\dist\electron.exe" "electron\main.cjs"
) else (
    start "" npx electron electron/main.cjs
)
exit
