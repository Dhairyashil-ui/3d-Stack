# NAKSHA 3D Desktop Workstation Launcher
Write-Host '===================================================================' -ForegroundColor Cyan
Write-Host '  NAKSHA 3D Desktop Application Suite v2.4.0 (Windows 64-bit)' -ForegroundColor Yellow
Write-Host '  Department of Land Resources (DoLR) | MPSEDC' -ForegroundColor Cyan
Write-Host '==================================================================='
Write-Host '[OK] Starting Desktop Workstation...' -ForegroundColor Green
Start-Process 'http://localhost:5173/desktop-app'
