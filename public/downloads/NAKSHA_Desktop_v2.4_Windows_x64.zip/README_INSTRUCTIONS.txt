===================================================================
NAKSHA 3D Desktop Application Suite (v2.4.0 - Windows 64-bit)
Ministry of Rural Development, Department of Land Resources (DoLR)
Developed by MPSEDC for Survey of India and Empaneled Surveyors
===================================================================

ABOUT THIS PACKAGE:
This is the official offline desktop workstation package for survey
agencies to validate feature extraction (.gdb) and orthorectified 
imagery (.tpk) files locally before submission to the WebGIS server.

HOW TO RUN:
Option 1: Double-click 'Launch_NAKSHA_Desktop.bat'
Option 2: Right-click 'Launch_NAKSHA_Desktop.ps1' -> 'Run with PowerShell'
Option 3: In the project root terminal, run:
          npm run desktop

SYSTEM REQUIREMENTS:
- OS: Windows 10 or 11 (64-bit)
- RAM: 16 GB DDR4 minimum
- GPU: Dedicated NVIDIA GTX/RTX 4GB+ with OpenGL 4.5+
- Storage: 20 GB free SSD space

DOCUMENTATION:
Refer to 'NAKSHA_Desktop_User_Manual.pdf' included in this folder for 
detailed step-by-step instructions on State selection, Guest Login,
and GDB/TPK verification procedures.
